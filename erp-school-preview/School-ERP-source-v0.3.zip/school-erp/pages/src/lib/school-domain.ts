export const ROLES=['manager','accountant','teacher','parent'] as const;
export type Role=typeof ROLES[number];
export function roleOf(value:unknown):Role{if(typeof value!=='string'||!(ROLES as readonly string[]).includes(value))throw new Error('نقش نامعتبر است.');return value as Role;}
export function canFinance(role:Role){return role==='manager'||role==='accountant';}
export function cleanText(v:unknown,name:string,max=100){if(typeof v!=='string')throw new Error(name+' را وارد کنید.');const s=v.trim();if(!s||s.length>max)throw new Error(name+' معتبر نیست.');return s;}
export function toRial(v:unknown){const normalized=String(v??'').replace(/[۰-۹]/g,c=>String('۰۱۲۳۴۵۶۷۸۹'.indexOf(c))).replace(/[٠-٩]/g,c=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(c))).replace(/[,٬\s]/g,'');if(!/^\d+$/.test(normalized))throw new Error('مبلغ را به تومان و بدون اعشار وارد کنید.');const n=Number(normalized);if(!Number.isSafeInteger(n)||n<=0||n>1_000_000_000)throw new Error('مبلغ باید بین ۱ و یک میلیارد تومان باشد.');return n*10;}
export function isoDay(v:unknown){const s=String(v??'');if(!/^\d{4}-\d{2}-\d{2}$/.test(s)||Number.isNaN(Date.parse(s+'T12:00:00Z'))||new Date(s+'T12:00:00Z').toISOString().slice(0,10)!==s)throw new Error('تاریخ معتبر نیست.');return s;}
export const accounts:Record<string,string>={'1101':'بانک مدرسه','1301':'دریافتنی شهریه','2101':'تعهد خدمات آموزشی'};
