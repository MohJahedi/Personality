import {roleOf,toRial,isoDay,cleanText,type Role} from './lib/school-domain';
type Row=Record<string,any>;
type Demo={students:Row[];invoices:Row[];receipts:Row[];journals:Row[];attendance:Row[];audit:Row[]};
const uuid=()=>Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,'0')).join('');
export const names:Record<Role,string>={manager:'مدیر نمونه',accountant:'حسابدار نمونه',teacher:'معلم نمونه',parent:'ولی نمونه'};
export function selectedRole(){try{return roleOf(sessionStorage.getItem('school-demo-role'));}catch{return null;}}
export function chooseRole(role:Role){sessionStorage.setItem('school-demo-role',role);window.location.hash='dashboard';}
export function leaveDemo(){sessionStorage.removeItem('school-demo-role');window.location.hash='login';}
function seed():Demo{
 const d:Demo={students:[],invoices:[],receipts:[],journals:[],attendance:[],audit:[]},created=new Date().toISOString();
 const fees=[40,42,39,41,44,40],paid=[12,18,0,20,10,16];
 for(let n=1;n<=6;n++){
  const sid='sample-'+n,iid='invoice-'+n;
  d.students.push({id:sid,name:'دانش‌آموز نمونهٔ '+n,code:'S-00'+n,class_name:n<=3?'پنجم الف':'پنجم ب',guardian_name:'ولی نمونهٔ '+n,guardian_phone:''});
  d.invoices.push({id:iid,student_id:sid,title:'شهریهٔ نمونهٔ سال تحصیلی',amount:fees[n-1]*10_000_000,due_date:'2026-11-15',created_at:created,event_key:'seed-fee-'+n});
  d.journals.push({id:'ji-'+n,student_id:sid,event_id:iid,event_type:'invoice',description:'مطالبهٔ شهریهٔ نمونه',debit_account:'1301',credit_account:'2101',amount:fees[n-1]*10_000_000,created_at:created});
  if(paid[n-1]){const rid='receipt-'+n;d.receipts.push({id:rid,invoice_id:iid,amount:paid[n-1]*10_000_000,reference:'دادهٔ ساختگی',created_at:created,event_key:'seed-pay-'+n});d.journals.push({id:'jr-'+n,student_id:sid,event_id:rid,event_type:'receipt',description:'دریافت نمونهٔ شهریه',debit_account:'1101',credit_account:'1301',amount:paid[n-1]*10_000_000,created_at:created});}
 }
 d.audit.push({role:'manager',action:'آماده‌سازی دادهٔ ساختگی این مرورگر',created_at:created});return d;
}
let opening:Promise<IDBDatabase>|null=null;
function database(){if(!opening)opening=new Promise((resolve,reject)=>{const r=indexedDB.open('school-erp-pages-demo-v1',1);r.onupgradeneeded=()=>r.result.createObjectStore('school');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(new Error('دسترسی به ذخیرهٔ مرورگر ممکن نشد.'));});return opening;}
async function transact<T>(fn:(data:Demo)=>T,write=false):Promise<T>{const db=await database();return new Promise((resolve,reject)=>{const tx=db.transaction('school','readwrite'),store=tx.objectStore('school'),get=store.get('demo');let result:T;let failed:unknown=null;get.onsuccess=()=>{try{const current=get.result as Demo|undefined,d=current||seed();result=fn(d);if(write||!current)store.put(d,'demo');}catch(e){failed=e;tx.abort();}};get.onerror=()=>{failed=new Error('خواندن دادهٔ آزمایشی ممکن نشد.');};tx.oncomplete=()=>resolve(result);tx.onabort=()=>reject(failed||new Error('ثبت دادهٔ آزمایشی انجام نشد.'));tx.onerror=()=>{failed=failed||new Error('ذخیرهٔ دادهٔ مرورگر ممکن نشد.');};});}
function visible(d:Demo,role:Role){
 const students=d.students.filter(s=>role==='teacher'?s.class_name==='پنجم الف':role==='parent'?s.id==='sample-1':true),ids=new Set(students.map(s=>s.id)),sm=new Map(students.map(s=>[s.id,s]));
 const invoices=d.invoices.filter(i=>ids.has(i.student_id)),im=new Map(invoices.map(i=>[i.id,i]));
 return {workspace:{title:'مدرسهٔ آزمایشی',academic_year:'۱۴۰۵–۱۴۰۶'},viewer:{name:names[role],email:'حساب نمایشی',role,className:role==='teacher'?'پنجم الف':null,studentId:role==='parent'?'sample-1':null},role,students,
  invoices:role==='teacher'?[]:invoices.map(i=>({...i,student_name:sm.get(i.student_id)?.name,student_code:sm.get(i.student_id)?.code,paid:d.receipts.filter(r=>r.invoice_id===i.id).reduce((n,r)=>n+r.amount,0)})),
  receipts:role==='teacher'?[]:d.receipts.filter(r=>im.has(r.invoice_id)).map(r=>({...r,student_name:sm.get(im.get(r.invoice_id)!.student_id)?.name,invoice_title:im.get(r.invoice_id)?.title})),
  journals:role==='manager'||role==='accountant'?d.journals.map(j=>({...j,student_name:sm.get(j.student_id)?.name})):[],
  attendance:role==='accountant'?[]:d.attendance.filter(a=>ids.has(a.student_id)).map(a=>({...a,student_name:sm.get(a.student_id)?.name})),audit:role==='manager'?d.audit.slice(-12).reverse():[]};
}
function change(d:Demo,role:Role,b:Row){
 const id=uuid(),created=new Date().toISOString(),action=b.action;
 function deny(){throw new Error('در این نمای آزمایشی اجازهٔ این عملیات وجود ندارد.');}
 if(action==='student'){
  if(role!=='manager')deny();const code=cleanText(b.code,'کد پرونده',30),cl=cleanText(b.className,'کلاس');if(!['پنجم الف','پنجم ب'].includes(cl))throw new Error('کلاس معتبر نیست.');if(d.students.some(s=>s.code===code))throw new Error('این کد قبلاً ثبت شده است.');
  d.students.push({id,name:cleanText(b.name,'نام دانش‌آموز'),code,class_name:cl,guardian_name:cleanText(b.guardianName,'نام ولی'),guardian_phone:String(b.guardianPhone||'').slice(0,25)});
 }else if(action==='invoice'||action==='receipt'){
  if(role!=='manager'&&role!=='accountant')deny();const amount=toRial(b.amount),event=cleanText(b.eventKey,'شناسهٔ درخواست',100);
  if(action==='invoice'){
   const sid=cleanText(b.studentId,'دانش‌آموز',180),title=cleanText(b.title,'عنوان'),due=isoDay(b.dueDate),old=d.invoices.find(i=>i.event_key===event);if(old){if(old.student_id!==sid||old.amount!==amount||old.title!==title||old.due_date!==due)throw new Error('شناسهٔ درخواست قبلاً استفاده شده است.');return {ok:true,repeated:true};}
   if(!d.students.some(s=>s.id===sid))throw new Error('دانش‌آموز یافت نشد.');d.invoices.unshift({id,student_id:sid,title,due_date:due,amount,event_key:event,created_at:created});d.journals.unshift({id:uuid(),student_id:sid,event_id:id,event_type:'invoice',description:title,debit_account:'1301',credit_account:'2101',amount,created_at:created});
  }else{
   const invoice=cleanText(b.invoiceId,'شهریه',180),old=d.receipts.find(r=>r.event_key===event);if(old){if(old.invoice_id!==invoice||old.amount!==amount)throw new Error('شناسهٔ درخواست قبلاً استفاده شده است.');return {ok:true,repeated:true};}
   const fee=d.invoices.find(i=>i.id===invoice);if(!fee)throw new Error('شهریه یافت نشد.');const paid=d.receipts.filter(r=>r.invoice_id===invoice).reduce((n,r)=>n+r.amount,0);if(amount>fee.amount-paid)throw new Error('مبلغ دریافت از ماندهٔ شهریه بیشتر است.');const reference=String(b.reference||'دریافت آزمایشی').trim().slice(0,100);
   d.receipts.unshift({id,invoice_id:invoice,amount,event_key:event,reference,created_at:created});d.journals.unshift({id:uuid(),student_id:fee.student_id,event_id:id,event_type:'receipt',description:'دریافت شهریه · '+reference,debit_account:'1101',credit_account:'1301',amount,created_at:created});
  }
 }else if(action==='attendance'){
  if(role!=='manager'&&role!=='teacher')deny();const sid=cleanText(b.studentId,'دانش‌آموز',180),day=isoDay(b.day),status=b.status,s=d.students.find(s=>s.id===sid);if(!s||(role==='teacher'&&s.class_name!=='پنجم الف'))deny();if(!['present','absent','late'].includes(status))throw new Error('وضعیت معتبر نیست.');const old=d.attendance.find(a=>a.student_id===sid&&a.day===day);if(old)old.status=status;else d.attendance.push({student_id:sid,day,status});
 }else throw new Error('عملیات در این دمو فعال نیست.');
 const label:Record<string,string>={student:'ثبت پروندهٔ ساختگی',invoice:'تعریف شهریهٔ ساختگی',receipt:'ثبت دریافت ساختگی',attendance:'ثبت حضور ساختگی'};d.audit.push({role,action:label[action],created_at:created});return {ok:true,id};
}
export async function demoFetch(_input:string,options?:RequestInit):Promise<Response>{
 try{if(options?.signal?.aborted)throw new DOMException('Aborted','AbortError');const role=selectedRole();if(!role)return Response.json({error:'ورود به نمای آزمایشی لازم است.'},{status:401});const write=options?.method==='POST',body=write?JSON.parse(String(options?.body||'{}')):{};const data=await transact(d=>write?change(d,role,body):visible(d,role),write);if(options?.signal?.aborted)throw new DOMException('Aborted','AbortError');return Response.json(data);}catch(e){if(e instanceof DOMException&&e.name==='AbortError')throw e;return Response.json({error:e instanceof Error?e.message:'ذخیرهٔ مرورگر در دسترس نیست.'},{status:400});}
}
