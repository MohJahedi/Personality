import React,{useEffect,useState} from 'react';
import {createRoot} from 'react-dom/client';
import LocalLogin from './app/local-login';
import SchoolApp from './app/school-app';
import type {Role} from './lib/school-domain';
import './app/globals.css';
function Gate(){
 const [role,setRole]=useState<Role|null>(null),[error,setError]=useState('');
 useEffect(()=>{fetch('/api/access',{cache:'no-store'}).then(async r=>{const d=await r.json() as {member:{role:Role;status:string}|null};if(!r.ok||!d.member||d.member.status!=='active'){window.location.replace('/');return;}setRole(d.member.role);}).catch(()=>setError('ارتباط با برنامه برقرار نشد. صفحه را بازخوانی کنید.'));},[]);
 return role?<SchoolApp initialRole={role}/>:<main className="loading">{error||'در حال ورود به میز کار…'}</main>;
}
function Logout(){useEffect(()=>{fetch('/api/auth',{method:'POST',headers:{'content-type':'application/json','x-school-erp':'1'},body:JSON.stringify({action:'logout'})}).finally(()=>window.location.replace('/'));},[]);return <main className="loading">در حال خروج…</main>;}
createRoot(document.getElementById('root')!).render(window.location.pathname==='/logout'?<Logout/>:window.location.pathname==='/dashboard'?<Gate/>:<LocalLogin/>);
