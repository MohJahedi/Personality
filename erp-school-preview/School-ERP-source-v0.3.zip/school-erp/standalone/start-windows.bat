@echo off
setlocal
cd /d "%~dp0"
py -3 --version >nul 2>&1
if not errorlevel 1 (
  py -3 server.py --open
  goto done
)
python --version >nul 2>&1
if not errorlevel 1 (
  python server.py --open
  goto done
)
echo Python 3.11 or newer is required. Open README_FA.html for setup.
start "" "%~dp0README_FA.html"
:done
pause
endlocal
