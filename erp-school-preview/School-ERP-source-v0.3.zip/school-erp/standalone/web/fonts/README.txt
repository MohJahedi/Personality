Optional licensed font files: IRANSans-Regular.woff2 and IRANSans-Bold.woff2
No font binary is included. The server loads files placed in this folder.
