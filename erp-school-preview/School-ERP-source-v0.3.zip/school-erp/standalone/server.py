"""Standalone School ERP pilot. Standard-library-only local server and WSGI app."""
from __future__ import annotations
import argparse
import base64
from contextlib import contextmanager
from datetime import datetime, timezone, date, timedelta
import hashlib
import hmac
from http.cookies import SimpleCookie
import json
import mimetypes
import os
from pathlib import Path
import re
import secrets
import sqlite3
import sys
import tempfile
import threading
import time
from urllib.parse import parse_qs
import webbrowser
from wsgiref.simple_server import make_server, WSGIServer, WSGIRequestHandler
from socketserver import ThreadingMixIn

ROOT = Path(__file__).resolve().parent
ITERATIONS = 600_000
COOKIE = 'school_session'
CLASSES = ('پنجم الف', 'پنجم ب')
ROLES = ('manager', 'accountant', 'teacher', 'parent')

class AppError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status

def now():
    return datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')

def uid():
    return secrets.token_hex(16)

def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()

def password_hash(password):
    salt = secrets.token_bytes(16)
    hashed = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, ITERATIONS)
    return f'pbkdf2_sha256${ITERATIONS}${salt.hex()}${hashed.hex()}'

def password_matches(password, encoded):
    try:
        algo, count, salt, expected = encoded.split('$')
        if algo != 'pbkdf2_sha256' or not 600_000 <= int(count) <= 2_000_000:
            return False
        actual = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), bytes.fromhex(salt), int(count))
        return hmac.compare_digest(actual, bytes.fromhex(expected))
    except (ValueError, TypeError):
        return False

def credentials(b):
    username = str(b.get('username', '')).strip().lower()
    password = b.get('password', '')
    if not re.fullmatch(r'[a-z][a-z0-9_.-]{2,39}', username):
        raise AppError('نام کاربری باید ۳ تا ۴۰ حرف انگلیسی، عدد، نقطه یا زیرخط باشد و با حرف شروع شود.')
    if not isinstance(password, str) or not 12 <= len(password) <= 128:
        raise AppError('گذرواژه باید بین ۱۲ تا ۱۲۸ نویسه باشد.')
    return username, password

def text(b, key, title, maximum=100):
    value = b.get(key)
    if not isinstance(value, str) or not value.strip() or len(value.strip()) > maximum:
        raise AppError(f'{title} معتبر نیست.')
    return value.strip()

def money(value):
    table = str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789')
    value = re.sub(r'[,٬\s]', '', str(value).translate(table))
    if not re.fullmatch('[0-9]+', value) or len(value) > 10 or not 1 <= int(value) <= 1_000_000_000:
        raise AppError('مبلغ را به تومان، بدون اعشار و بین ۱ تا یک میلیارد وارد کنید.')
    return int(value) * 10

def day(value):
    try:
        value = str(value)
        if date.fromisoformat(value).isoformat() != value:
            raise ValueError()
        return value
    except ValueError:
        raise AppError('تاریخ معتبر نیست.')

class School:
    def __init__(self, data_dir, allowed_hosts=None, secure_cookie=False, setup_token=None):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        try:
            self.data_dir.chmod(0o700)
        except OSError:
            pass
        self.db_path = self.data_dir / 'school.sqlite3'
        self.allowed_hosts = {h.lower() for h in (allowed_hosts or ['127.0.0.1:8765', 'localhost:8765'])}
        self.secure_cookie = secure_cookie
        self.setup_digest = digest(setup_token) if setup_token else None
        with self.connection() as db:
            version = db.execute('PRAGMA user_version').fetchone()[0]
            if version == 0:
                db.executescript((ROOT / 'schema.sql').read_text('utf-8'))
            elif version != 3:
                raise RuntimeError('Unsupported database version; do not overwrite existing data.')
        try:
            self.db_path.chmod(0o600)
        except OSError:
            pass
        self.dummy_hash = password_hash(secrets.token_urlsafe(24))

    @contextmanager
    def connection(self):
        db = sqlite3.connect(self.db_path, timeout=15, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        db.execute('PRAGMA busy_timeout=15000')
        try:
            yield db
        finally:
            db.close()

    @contextmanager
    def transaction(self):
        with self.connection() as db:
            db.execute('BEGIN IMMEDIATE')
            try:
                yield db
                db.execute('COMMIT')
            except BaseException:
                db.execute('ROLLBACK')
                raise

    def session_user(self, db, environ):
        cookie = SimpleCookie()
        try:
            cookie.load(environ.get('HTTP_COOKIE', ''))
            token = cookie[COOKIE].value if COOKIE in cookie else ''
        except Exception:
            token = ''
        if not token or len(token) > 100:
            return None
        return db.execute('''SELECT u.id,u.username,u.display_name,m.owner,m.role,m.status,m.class_name,m.student_id
          FROM local_sessions s JOIN local_users u ON u.id=s.user_id JOIN memberships m ON m.user_id=u.id
          WHERE s.token_hash=? AND s.expires_at>?''', (digest(token), int(time.time()))).fetchone()

    def active_user(self, db, environ, manager=False):
        user = self.session_user(db, environ)
        if not user:
            raise AppError('ورود به حساب لازم است.', 401)
        if user['status'] != 'active':
            raise AppError('دسترسی شما توسط مدیر غیرفعال شده است.', 403)
        if manager and (user['role'] != 'manager' or user['id'] != user['owner']):
            raise AppError('این عملیات فقط برای مدیر مدرسه مجاز است.', 403)
        return user

    def new_session(self, db, user_id):
        token = secrets.token_urlsafe(32)
        db.execute('DELETE FROM local_sessions WHERE expires_at<=?', (int(time.time()),))
        db.execute('INSERT INTO local_sessions VALUES(?,?,?)', (digest(token), user_id, int(time.time()) + 8*3600))
        suffix = '; Secure' if self.secure_cookie else ''
        return ('Set-Cookie', f'{COOKIE}={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=28800{suffix}')

    def log(self, db, user, action, target):
        db.execute('INSERT INTO audit VALUES(?,?,?,?,?,?)', (uid(), user['owner'], user['role'], action, target, now()))

    def seed(self, db, owner):
        created = now()
        db.execute('INSERT INTO workspaces VALUES(?,?,?,?,?)', (owner, 'مدرسهٔ آزمایشی', '۱۴۰۵–۱۴۰۶', owner+':sample:1', created))
        for i, (fee, paid) in enumerate(zip([40,42,39,41,44,40], [12,18,0,20,10,16]), 1):
            sid, inv = f'{owner}:sample:{i}', f'{owner}:invoice:{i}'
            db.execute('INSERT INTO students VALUES(?,?,?,?,?,?,?,?)', (sid,owner,f'دانش‌آموز نمونهٔ {i}',f'S-00{i}',CLASSES[0 if i<=3 else 1],f'ولی نمونهٔ {i}','',created))
            db.execute('INSERT INTO invoices VALUES(?,?,?,?,?,?,?)', (inv,owner,sid,'شهریهٔ نمونهٔ سال تحصیلی',fee*10_000_000,'2026-11-15',created))
            db.execute('INSERT INTO journals VALUES(?,?,?,?,?,?,?,?,?,?)', (uid(),owner,sid,inv,'invoice','مطالبهٔ شهریهٔ نمونه','1301','2101',fee*10_000_000,created))
            if paid:
                receipt = uid()
                db.execute('INSERT INTO receipts VALUES(?,?,?,?,?,?,?,?)', (receipt,owner,inv,paid*10_000_000,'bank','دادهٔ ساختگی',f'seed-{i}',created))
                db.execute('INSERT INTO journals VALUES(?,?,?,?,?,?,?,?,?,?)', (uid(),owner,sid,receipt,'receipt','دریافت نمونهٔ شهریه','1101','1301',paid*10_000_000,created))

    def auth(self, action, b, environ):
        if action == 'logout':
            with self.transaction() as db:
                cookie = SimpleCookie()
                cookie.load(environ.get('HTTP_COOKIE',''))
                if COOKIE in cookie:
                    db.execute('DELETE FROM local_sessions WHERE token_hash=?', (digest(cookie[COOKIE].value),))
            suffix = '; Secure' if self.secure_cookie else ''
            return {'ok':True}, [('Set-Cookie',f'{COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0{suffix}')]
        if action not in ('login','setup','register'):
            raise AppError('عملیات شناخته نشد.')
        if action=='setup' and self.setup_digest and not hmac.compare_digest(digest(str(b.get('setupToken',''))), self.setup_digest):
            raise AppError('کد راه‌اندازی سرور صحیح نیست.',403)
        username, password = credentials(b)
        key = digest(environ.get('REMOTE_ADDR','local') + ':' + username)
        ipkey = digest('ip:' + environ.get('REMOTE_ADDR','local'))
        with self.connection() as db:
            for k in (key, ipkey):
                limit = db.execute('SELECT * FROM login_limits WHERE key=?', (k,)).fetchone()
                if limit and limit['failures'] >= 10 and limit['until_at'] > int(time.time()):
                    raise AppError('تلاش‌های ناموفق زیاد است؛ ۱۵ دقیقه بعد دوباره تلاش کنید.', 429)
            existing = db.execute('SELECT * FROM local_users WHERE username=?', (username,)).fetchone()
        if action == 'login':
            good = password_matches(password, existing['password_hash'] if existing else self.dummy_hash)
            if not existing or not good:
                with self.transaction() as db:
                    for k in (key, ipkey):
                        db.execute('''INSERT INTO login_limits VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET
                          failures=CASE WHEN until_at<=? THEN 1 ELSE failures+1 END,
                          until_at=CASE WHEN until_at<=? THEN excluded.until_at ELSE until_at END''', (k,int(time.time())+900,int(time.time()),int(time.time())))
                raise AppError('نام کاربری یا گذرواژه صحیح نیست.', 401)
            with self.transaction() as db:
                member = db.execute('SELECT * FROM memberships WHERE user_id=?', (existing['id'],)).fetchone()
                if not member or member['status'] != 'active':
                    raise AppError('دسترسی این حساب غیرفعال شده است.',403)
                db.execute('DELETE FROM login_limits WHERE key=?', (key,))
                header = self.new_session(db, existing['id'])
                self.log(db, member, 'ورود به حساب محلی', existing['id'])
            return {'ok':True}, [header]
        name = text(b,'name','نام نمایشی')
        encoded = password_hash(password)
        with self.transaction() as db:
            if existing or db.execute('SELECT id FROM local_users WHERE username=?',(username,)).fetchone():
                raise AppError('این نام کاربری قبلاً ثبت شده است.',409)
            user_id, created = uid(), now()
            if action == 'setup':
                if db.execute('SELECT id FROM local_users LIMIT 1').fetchone():
                    raise AppError('مدیر اولیه قبلاً ساخته شده است.',409)
                owner, role, class_name, student_id, invite_id = user_id,'manager',None,None,None
                self.seed(db,owner)
            else:
                token = text(b,'token','کد دعوت',100)
                if not re.fullmatch('[a-fA-F0-9]{64}',token):
                    raise AppError('کد دعوت معتبر نیست.')
                invite = db.execute('SELECT * FROM invitations WHERE token_hash=? AND revoked=0 AND used_by IS NULL AND expires_at>?', (digest(token),created)).fetchone()
                if not invite:
                    raise AppError('کد دعوت مصرف‌شده، لغوشده یا منقضی است.',409)
                owner,role,class_name,student_id,invite_id = [invite[k] for k in ('owner','role','class_name','student_id','id')]
            db.execute('INSERT INTO local_users VALUES(?,?,?,?,?)', (user_id,username,name,encoded,created))
            db.execute('INSERT INTO memberships VALUES(?,?,?,?,?,?,?,?,?,?)', (user_id,owner,role,name,username,'active',class_name,student_id,invite_id,created))
            if invite_id:
                db.execute('UPDATE invitations SET used_by=? WHERE id=? AND used_by IS NULL', (user_id,invite_id))
            member = db.execute('SELECT * FROM memberships WHERE user_id=?',(user_id,)).fetchone()
            self.log(db,member,'ساخت حساب مدیر' if action=='setup' else 'پیوستن کاربر دعوت‌شده',user_id)
            header = self.new_session(db,user_id)
        return {'ok':True}, [header]

    def scope(self, user):
        if user['role']=='teacher':
            return ' AND s.class_name=?', [user['class_name'] or '']
        if user['role']=='parent':
            return ' AND s.id=?', [user['student_id'] or '']
        return '', []

    def school_data(self, db, user):
        scope, params = self.scope(user)
        args = [user['owner'],*params]
        financial = user['role'] in ('manager','accountant')
        def rows(sql, values):
            return [dict(r) for r in db.execute(sql,values)]
        result = {
          'workspace':dict(db.execute('SELECT title,academic_year FROM workspaces WHERE owner=?',(user['owner'],)).fetchone()),
          'viewer':{'name':user['display_name'],'email':user['username'],'role':user['role'],'className':user['class_name'],'studentId':user['student_id']},
          'role':user['role'],
          'students':rows('SELECT s.* FROM students s WHERE s.owner=?'+scope+' ORDER BY s.code',args),
          'invoices':[], 'receipts':[], 'journals':[], 'attendance':[], 'audit':[]}
        if user['role']!='teacher':
            result['invoices']=rows('''SELECT i.*,s.name student_name,s.code student_code,COALESCE((SELECT SUM(r.amount) FROM receipts r WHERE r.owner=i.owner AND r.invoice_id=i.id),0) paid
             FROM invoices i JOIN students s ON s.id=i.student_id AND s.owner=i.owner WHERE i.owner=?'''+scope+' ORDER BY i.created_at DESC',args)
            result['receipts']=rows('''SELECT r.*,s.name student_name,i.title invoice_title FROM receipts r JOIN invoices i ON i.id=r.invoice_id AND i.owner=r.owner
              JOIN students s ON s.id=i.student_id AND s.owner=i.owner WHERE r.owner=?'''+scope+' ORDER BY r.created_at DESC',args)
        if user['role']!='accountant':
            result['attendance']=rows('SELECT a.*,s.name student_name FROM attendance a JOIN students s ON s.id=a.student_id AND s.owner=a.owner WHERE a.owner=?'+scope+' ORDER BY a.day DESC,s.code',args)
        if financial:
            result['journals']=rows('SELECT j.*,s.name student_name FROM journals j JOIN students s ON s.id=j.student_id AND s.owner=j.owner WHERE j.owner=? ORDER BY j.created_at DESC,j.id',(user['owner'],))
        if user['role']=='manager':
            result['audit']=rows('SELECT role,action,created_at FROM audit WHERE owner=? ORDER BY created_at DESC LIMIT 12',(user['owner'],))
        return result

    def operation(self, db, user, b):
        role,owner,created,ident = user['role'],user['owner'],now(),uid()
        action = b.get('action')
        if b.get('role',role)!=role:
            raise AppError('نقش درخواست با حساب شما تطابق ندارد.',403)
        if action=='student':
            if role!='manager':
                raise AppError('ثبت دانش‌آموز فقط برای مدیر مجاز است.',403)
            name,code,guardian = text(b,'name','نام دانش‌آموز'),text(b,'code','کد پرونده',30),text(b,'guardianName','نام ولی')
            cl = text(b,'className','کلاس')
            if cl not in CLASSES:
                raise AppError('کلاس معتبر نیست.')
            phone = str(b.get('guardianPhone','')).strip()
            if len(phone)>25:
                raise AppError('تماس ولی معتبر نیست.')
            db.execute('INSERT INTO students VALUES(?,?,?,?,?,?,?,?)',(ident,owner,name,code,cl,guardian,phone,created))
            self.log(db,user,'ثبت دانش‌آموز و ولی',ident)
        elif action in ('invoice','receipt'):
            if role not in ('manager','accountant'):
                raise AppError('این نقش اجازهٔ ثبت عملیات مالی ندارد.',403)
            amount,event = money(b.get('amount','')),text(b,'eventKey','شناسهٔ درخواست',100)
            if action=='invoice':
                sid,title,due = text(b,'studentId','دانش‌آموز',180),text(b,'title','عنوان شهریه'),day(b.get('dueDate'))
                ident = owner+':invoice-event:'+event
                old = db.execute('SELECT * FROM invoices WHERE owner=? AND id=?',(owner,ident)).fetchone()
                if old:
                    if (old['student_id'],old['title'],old['amount'],old['due_date'])!=(sid,title,amount,due):
                        raise AppError('شناسهٔ درخواست قبلاً برای شهریهٔ دیگری مصرف شده است.',409)
                    return {'ok':True,'repeated':True}
                if not db.execute('SELECT id FROM students WHERE id=? AND owner=?',(sid,owner)).fetchone():
                    raise AppError('دانش‌آموز یافت نشد.',404)
                db.execute('INSERT INTO invoices VALUES(?,?,?,?,?,?,?)',(ident,owner,sid,title,amount,due,created))
                db.execute('INSERT INTO journals VALUES(?,?,?,?,?,?,?,?,?,?)',(uid(),owner,sid,ident,'invoice',title,'1301','2101',amount,created))
                self.log(db,user,'تعریف شهریه و سند مرتبط',ident)
            else:
                invoice = text(b,'invoiceId','شهریه',180)
                old = db.execute('SELECT * FROM receipts WHERE owner=? AND event_key=?',(owner,event)).fetchone()
                if old:
                    if (old['invoice_id'],old['amount'])!=(invoice,amount):
                        raise AppError('شناسهٔ درخواست قبلاً برای دریافت دیگری مصرف شده است.',409)
                    return {'ok':True,'repeated':True}
                fee = db.execute('''SELECT i.*,i.amount-COALESCE((SELECT SUM(r.amount) FROM receipts r WHERE r.owner=i.owner AND r.invoice_id=i.id),0) remaining
                   FROM invoices i WHERE i.owner=? AND i.id=?''',(owner,invoice)).fetchone()
                if not fee:
                    raise AppError('شهریه یافت نشد.',404)
                if amount>fee['remaining']:
                    raise AppError('مبلغ دریافت از ماندهٔ شهریه بیشتر است.',409)
                reference = str(b.get('reference','ثبت آزمایشی')).strip()[:100]
                db.execute('INSERT INTO receipts VALUES(?,?,?,?,?,?,?,?)',(ident,owner,invoice,amount,'bank',reference,event,created))
                db.execute('INSERT INTO journals VALUES(?,?,?,?,?,?,?,?,?,?)',(uid(),owner,fee['student_id'],ident,'receipt','دریافت شهریه · '+reference,'1101','1301',amount,created))
                self.log(db,user,'ثبت دریافت و سند مرتبط',ident)
        elif action=='attendance':
            if role not in ('manager','teacher'):
                raise AppError('این نقش اجازهٔ ثبت حضور ندارد.',403)
            sid,status,selected_day = text(b,'studentId','دانش‌آموز',180),b.get('status'),day(b.get('day'))
            if status not in ('present','absent','late'):
                raise AppError('وضعیت معتبر نیست.')
            scope,args = self.scope(user)
            if not db.execute('SELECT s.id FROM students s WHERE s.owner=? AND s.id=?'+scope,[owner,sid,*args]).fetchone():
                raise AppError('به این دانش‌آموز دسترسی ندارید.',403)
            db.execute('''INSERT INTO attendance VALUES(?,?,?,?,?,?) ON CONFLICT(owner,student_id,day)
               DO UPDATE SET status=excluded.status,updated_at=excluded.updated_at''',(ident,owner,sid,selected_day,status,created))
            self.log(db,user,'ثبت حضور و غیاب',sid)
        else:
            raise AppError('عملیات شناخته نشد.')
        return {'ok':True,'id':ident}

    def access_operation(self, db, user, b):
        created,owner = now(),user['owner']
        if b.get('action')=='invite':
            role,label = b.get('role'),text(b,'label','عنوان دعوت',80)
            if role not in ('accountant','teacher','parent'):
                raise AppError('نقش دعوت معتبر نیست.')
            cl = text(b,'className','کلاس') if role=='teacher' else None
            sid = text(b,'studentId','دانش‌آموز',180) if role=='parent' else None
            if cl and cl not in CLASSES:
                raise AppError('کلاس معتبر نیست.')
            if sid and not db.execute('SELECT id FROM students WHERE id=? AND owner=?',(sid,owner)).fetchone():
                raise AppError('دانش‌آموز یافت نشد.',404)
            count = db.execute('SELECT COUNT(*) FROM invitations WHERE owner=? AND revoked=0 AND used_by IS NULL AND expires_at>?',(owner,created)).fetchone()[0]
            if count>=10:
                raise AppError('حداکثر ۱۰ دعوت فعال مجاز است؛ دعوت قبلی را لغو کنید.',409)
            token,ident = secrets.token_hex(32),uid()
            expires = (datetime.now(timezone.utc)+timedelta(days=7)).isoformat(timespec='milliseconds').replace('+00:00','Z')
            db.execute('INSERT INTO invitations VALUES(?,?,?,?,?,?,?,?,?,?,?)',(ident,owner,digest(token),role,label,cl,sid,expires,0,None,created))
            self.log(db,user,'ایجاد دعوت کاربر',ident)
            return {'ok':True,'token':token,'expiresAt':expires}
        if b.get('action')=='revokeInvite':
            ident = text(b,'id','دعوت',100)
            updated = db.execute('UPDATE invitations SET revoked=1 WHERE id=? AND owner=? AND used_by IS NULL',(ident,owner)).rowcount
            if not updated:
                raise AppError('دعوت قابل لغو یافت نشد.',404)
            self.log(db,user,'لغو دعوت کاربر',ident)
            return {'ok':True}
        if b.get('action')=='memberStatus':
            target,status = text(b,'userId','کاربر',180),b.get('status')
            if status not in ('active','disabled'):
                raise AppError('وضعیت معتبر نیست.')
            if not db.execute("SELECT user_id FROM memberships WHERE owner=? AND user_id=? AND role<>'manager'",(owner,target)).fetchone():
                raise AppError('این کاربر قابل تغییر نیست.',403)
            db.execute('UPDATE memberships SET status=? WHERE owner=? AND user_id=?',(status,owner,target))
            if status=='disabled':
                db.execute('DELETE FROM local_sessions WHERE user_id=?',(target,))
            self.log(db,user,'فعال‌سازی دسترسی' if status=='active' else 'غیرفعال‌سازی دسترسی',target)
            return {'ok':True}
        raise AppError('عملیات شناخته نشد.')

    def json_response(self, obj, status=200, extra=None):
        return status, [('Content-Type','application/json; charset=utf-8'),*(extra or [])],json.dumps(obj,ensure_ascii=False).encode('utf-8')

    def handle(self, environ):
        method,path = environ.get('REQUEST_METHOD','GET'),environ.get('PATH_INFO','/')
        host = environ.get('HTTP_HOST','').lower()
        if host not in self.allowed_hosts:
            raise AppError('نشانی میزبان مجاز نیست.',403)
        if method not in ('GET','HEAD','POST'):
            raise AppError('روش درخواست مجاز نیست.',405)
        b = {}
        if method=='POST':
            origin = environ.get('HTTP_ORIGIN')
            if origin and origin not in {scheme+'://'+h for h in self.allowed_hosts for scheme in ('http','https')}:
                raise AppError('مبدأ درخواست مجاز نیست.',403)
            if environ.get('HTTP_SEC_FETCH_SITE')=='cross-site' or environ.get('HTTP_X_SCHOOL_ERP')!='1' or not environ.get('CONTENT_TYPE','').startswith('application/json'):
                raise AppError('درخواست مجاز نیست.',403)
            try:
                length = int(environ.get('CONTENT_LENGTH','0'))
                if not 0<length<=16000:
                    raise AppError('حجم درخواست معتبر نیست.',413)
                b = json.loads(environ['wsgi.input'].read(length))
                if not isinstance(b,dict):
                    raise ValueError()
            except (ValueError,UnicodeDecodeError):
                raise AppError('درخواست معتبر نیست.')
        if path=='/api/auth' and method=='POST':
            result,headers = self.auth(b.get('action'),b,environ)
            return self.json_response(result,extra=headers)
        if path=='/api/access' and method=='GET':
            with self.connection() as db:
                user = self.session_user(db,environ)
                if parse_qs(environ.get('QUERY_STRING','')).get('manage')==['1']:
                    user = self.active_user(db,environ,True)
                    members = [dict(r) for r in db.execute('SELECT user_id,display_name,email,role,status,class_name,student_id,created_at FROM memberships WHERE owner=? ORDER BY created_at',(user['owner'],))]
                    invites = [dict(r) for r in db.execute('SELECT id,label,role,class_name,student_id,expires_at,revoked,used_by,created_at FROM invitations WHERE owner=? ORDER BY created_at DESC LIMIT 50',(user['owner'],))]
                    return self.json_response({'members':members,'invitations':invites})
                setup = not db.execute('SELECT id FROM local_users LIMIT 1').fetchone()
                return self.json_response({'setupRequired':setup,'setupProtected':bool(self.setup_digest),'user':{'name':user['display_name'],'email':user['username']} if user else None,'member':{'role':user['role'],'status':user['status'],'className':user['class_name'],'studentId':user['student_id']} if user else None})
        if path=='/api/access' and method=='POST':
            with self.transaction() as db:
                user = self.active_user(db,environ,True)
                return self.json_response(self.access_operation(db,user,b))
        if path=='/api/school' and method in ('GET','POST'):
            with self.transaction() as db:
                user = self.active_user(db,environ)
                requested = parse_qs(environ.get('QUERY_STRING','')).get('role',[user['role']])[0]
                if requested!=user['role']:
                    raise AppError('نقش درخواست با حساب شما تطابق ندارد.',403)
                return self.json_response(self.school_data(db,user) if method=='GET' else self.operation(db,user,b))
        if path=='/api/backup' and method=='GET':
            with self.connection() as db:
                self.active_user(db,environ,True)
                with tempfile.TemporaryDirectory() as temporary:
                    backup = Path(temporary)/'backup.sqlite3'
                    dest = sqlite3.connect(backup)
                    try:
                        db.backup(dest)
                    finally:
                        dest.close()
                    data = backup.read_bytes()
            return 200,[('Content-Type','application/vnd.sqlite3'),('Content-Disposition',f'attachment; filename="school-backup-{date.today().isoformat()}.sqlite3"')],data
        if path=='/font.css' and method in ('GET','HEAD'):
            rules=[]
            for filename,weight in [('IRANSans-Regular.woff2','400'),('IRANSans-Bold.woff2','700')]:
                if (ROOT/'web'/'fonts'/filename).is_file():
                    rules.append('@font-face{font-family:IRANSans;src:url("/fonts/'+filename+'") format("woff2");font-weight:'+weight+';font-style:normal;font-display:swap;}')
            return 200,[('Content-Type','text/css; charset=utf-8')],'\n'.join(rules).encode()
        if path.startswith('/api/'):
            raise AppError('مسیر یافت نشد.',404)
        if method=='POST':
            raise AppError('مسیر یافت نشد.',404)
        if path=='/dashboard':
            with self.connection() as db:
                user = self.session_user(db,environ)
                if not user or user['status']!='active':
                    return 302,[('Location','/')],b''
        if path not in ('/','/login','/dashboard','/logout','/favicon.svg') and not path.startswith('/assets/') and not path.startswith('/fonts/'):
            raise AppError('مسیر یافت نشد.',404)
        relative = 'index.html' if path in ('/','/login','/dashboard','/logout') else path.lstrip('/')
        file = (ROOT/'web'/relative).resolve()
        if not file.is_relative_to((ROOT/'web').resolve()) or not file.is_file():
            raise AppError('فایل رابط یافت نشد؛ پوشهٔ web را همراه برنامه نگه دارید.',404)
        return 200,[('Content-Type',mimetypes.guess_type(file)[0] or 'application/octet-stream')],file.read_bytes()

    def __call__(self,environ,start_response):
        try:
            status,headers,body = self.handle(environ)
        except AppError as error:
            status,headers,body = self.json_response({'error':str(error)},error.status)
        except sqlite3.IntegrityError:
            status,headers,body = self.json_response({'error':'کد پرونده، نام کاربری یا درخواست قبلاً ثبت شده است.'},409)
        except Exception:
            # Never print cookies, passwords, invite codes, request bodies or SQL parameters.
            print('School request failed; inspect local setup and database.',file=sys.stderr)
            status,headers,body = self.json_response({'error':'عملیات انجام نشد. دوباره تلاش کنید.'},500)
        base = [('Cache-Control','no-store'),('X-Content-Type-Options','nosniff'),('Referrer-Policy','no-referrer'),('X-Frame-Options','SAMEORIGIN'),('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'self'; object-src 'none'; base-uri 'none'")]
        headers.extend(base)
        headers.append(('Content-Length',str(len(body))))
        reason = {200:'OK',302:'Found',400:'Bad Request',401:'Unauthorized',403:'Forbidden',404:'Not Found',405:'Method Not Allowed',409:'Conflict',413:'Payload Too Large',429:'Too Many Requests',500:'Internal Server Error'}.get(status,'Error')
        start_response(f'{status} {reason}',headers)
        return [b'' if environ.get('REQUEST_METHOD')=='HEAD' else body]

class ThreadingServer(ThreadingMixIn,WSGIServer):
    daemon_threads=True

class QuietHandler(WSGIRequestHandler):
    def log_message(self,format,*args):
        pass

def main():
    if sys.version_info<(3,11):
        raise SystemExit('Python 3.11 or newer is required. See README_FA.html.')
    parser=argparse.ArgumentParser(description='Standalone school pilot; local use by default.')
    parser.add_argument('--host','--bind',default='127.0.0.1')
    parser.add_argument('--port',type=int,default=8765)
    parser.add_argument('--data-dir',default=str(ROOT/'data'))
    parser.add_argument('--allow-host',action='append',default=[])
    parser.add_argument('--secure-cookies',action='store_true')
    parser.add_argument('--open',action='store_true')
    parser.add_argument('--preview',action='store_true',help=argparse.SUPPRESS)
    parser.add_argument('--strictPort',action='store_true',help=argparse.SUPPRESS)
    parser.add_argument('--reset-admin',action='store_true')
    args=parser.parse_args()
    if args.preview:
        args.data_dir=str(Path(tempfile.gettempdir())/'school-local-v03-qa')
        args.allow_host.extend([f'terminal.local:{args.port}','terminal.local'])
    application=School(args.data_dir,[f'localhost:{args.port}',f'127.0.0.1:{args.port}',*args.allow_host],args.secure_cookies)
    if args.reset_admin:
        import getpass
        password=getpass.getpass('New admin password (12+ characters): ')
        repeat=getpass.getpass('Repeat new password: ')
        if password!=repeat or not 12<=len(password)<=128:
            raise SystemExit('Passwords must match and contain 12-128 characters.')
        with application.transaction() as db:
            admin=db.execute("SELECT user_id FROM memberships WHERE role='manager' LIMIT 1").fetchone()
            if not admin:
                raise SystemExit('No admin exists yet; open the first-run page.')
            db.execute('UPDATE local_users SET password_hash=? WHERE id=?',(password_hash(password),admin['user_id']))
            db.execute('DELETE FROM local_sessions WHERE user_id=?',(admin['user_id'],))
        print('Admin password updated; previous sessions revoked.')
        return
    try:
        httpd=make_server(args.host,args.port,application,server_class=ThreadingServer,handler_class=QuietHandler)
    except OSError:
        raise SystemExit('Port is already in use. Close the other copy or use --port 8766.')
    address=f'http://127.0.0.1:{args.port}/'
    print(f'School ERP local pilot: {address}',flush=True)
    print('Keep this window open. Press Ctrl+C to stop. Data stays on this computer.',flush=True)
    if args.open:
        threading.Timer(.5,lambda:webbrowser.open(address)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()

if __name__=='__main__':
    main()
