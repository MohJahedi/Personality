"""Independent-hosting entry point; initialize a private staging environment first."""
import os
from server import School
hosts=[h.strip() for h in os.environ.get('SCHOOL_ALLOWED_HOSTS','').split(',') if h.strip()]
if not hosts or '*' in hosts:
    raise RuntimeError('Set SCHOOL_ALLOWED_HOSTS to the exact intended domain; wildcard is not supported.')
app=School(os.environ.get('SCHOOL_DATA_DIR','data'),hosts,os.environ.get('SCHOOL_SECURE_COOKIES','1')=='1',os.environ.get('SCHOOL_SETUP_TOKEN'))
with app.connection() as db:
    if not db.execute('SELECT id FROM local_users LIMIT 1').fetchone() and not app.setup_digest:
        raise RuntimeError('Set a random SCHOOL_SETUP_TOKEN before first startup; it protects administrator setup.')
