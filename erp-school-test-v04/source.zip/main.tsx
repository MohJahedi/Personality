import {createRoot} from 'react-dom/client';
import {useEffect,useState} from 'react';
import App from './frontend/app/App';
import './frontend/styles/fonts.css';
import './frontend/styles/app.css';
import './sandbox.css';

type Mode = 'demo'|'empty';
type Info = {mode:Mode;demoRoles:string[];canRestore:boolean};
type Result = {status:number;headers:[string,string][];body64:string};
const roles:Record<string,string>={system_admin:'ادمین سیستم',manager:'مدیر',accountant:'حسابدار',teacher:'معلم',parent:'ولی',student:'دانش‌آموز'};
const worker = new Worker(new URL('./sandbox-worker.js',document.baseURI),{type:'module'});
let sequence=0;
const waiting=new Map<number,{resolve:(result:unknown)=>void;reject:(error:Error)=>void}>();
let notifyProgress = (_:string)=>{};
worker.onmessage = ({data}) => {
  if(data.kind==='progress'){notifyProgress(data.text);return;}
  const pending=waiting.get(data.id); if(!pending)return;
  waiting.delete(data.id);
  if(data.kind==='error')pending.reject(new Error(data.error));else pending.resolve(data.result);
};
worker.onerror = () => { for(const item of waiting.values())item.reject(new Error('بارگذاری موتور محیط تست ممکن نشد؛ صفحه را دوباره باز کنید.'));waiting.clear(); };
function rpc<T>(message:Record<string,unknown>):Promise<T>{return new Promise((resolve,reject)=>{const id=++sequence;waiting.set(id,{resolve:result=>resolve(result as T),reject});worker.postMessage({...message,id});});}
function responseFrom(result:Result){const bytes=Uint8Array.from(atob(result.body64),character=>character.charCodeAt(0));return new Response(bytes,{status:result.status,headers:result.headers});}
const nativeFetch=window.fetch.bind(window);
window.fetch=async(input:RequestInfo|URL,init?:RequestInit)=>{
  const url=new URL(input instanceof Request?input.url:String(input),location.href);
  if(url.origin!==location.origin || !(url.pathname.startsWith('/api/v1/') || url.pathname==='/api/backup'))return nativeFetch(input,init);
  const signal=init?.signal;
  if(signal?.aborted)throw new DOMException('Aborted','AbortError');
  const method=(init?.method||'GET').toUpperCase();
  const body=init?.body ? JSON.parse(String(init.body)) : undefined;
  const result=await rpc<Result>({kind:'request',request:{path:url.pathname+url.search,method,body}});
  if(signal?.aborted)throw new DOMException('Aborted','AbortError');
  return responseFrom(result);
};
async function downloadBackup(){
  const response=await fetch('/api/backup');
  if(!response.ok){const result=await response.json();throw new Error(result.error||'گرفتن پشتیبان ممکن نشد.');}
  const objectUrl=URL.createObjectURL(await response.blob());
  const anchor=document.createElement('a');anchor.href=objectUrl;anchor.download='school-test-v04.sqlite3';anchor.click();
  setTimeout(()=>URL.revokeObjectURL(objectUrl),1000);
}

function Sandbox(){
  const [info,setInfo]=useState<Info>(),[mode,setMode]=useState<Mode>('demo'),[role,setRole]=useState('system_admin');
  const [busy,setBusy]=useState(true),[progress,setProgress]=useState('در حال آماده‌سازی محیط تست…'),[error,setError]=useState(''),[revision,setRevision]=useState(0);
  const [confirmReset,setConfirmReset]=useState(false);
  useEffect(()=>{
    notifyProgress=setProgress;
    let release=()=>{};
    const start=async()=>{
      try{setInfo(await rpc<Info>({kind:'boot',hostname:location.host,mode:'demo'}));setBusy(false);}
      catch(e){setError(e instanceof Error?e.message:'محیط تست آماده نشد.');setBusy(false);}
    };
    if(navigator.locks){
      void navigator.locks.request('erp-school-browser-test-v04-exclusive',{ifAvailable:true},async lock=>{
        if(!lock){setError('این محیط تست در تب دیگری باز است. تب قبلی را ببندید و این صفحه را بازخوانی کنید.');setBusy(false);return;}
        await start(); await new Promise<void>(resolve=>{release=resolve;});
      });
    }else{setError('برای حفظ داده‌های تست، از نسخهٔ جدید Chrome، Edge، Firefox یا Safari استفاده کنید.');setBusy(false);}
    return ()=>release();
  },[]);
  useEffect(()=>{
    const click=(event:MouseEvent)=>{const anchor=(event.target as Element).closest('a[href="/api/backup"]');if(anchor){event.preventDefault();void downloadBackup().catch(e=>setError(String(e.message)));}};
    document.addEventListener('click',click);return ()=>document.removeEventListener('click',click);
  },[]);
  async function action(task:()=>Promise<void>){setBusy(true);setError('');setConfirmReset(false);try{await task();setRevision(n=>n+1);}catch(e){setError(e instanceof Error?e.message:'عملیات کامل نشد.');}finally{setBusy(false);}}
  async function changeMode(next:Mode){await action(async()=>{setInfo(await rpc<Info>({kind:'mode',hostname:location.host,mode:next}));setMode(next);});}
  return <><section className="sandbox-bar" aria-label="کنترل محیط تست"><div className="sandbox-description"><strong>محیط تست محصول · ۰٫۴</strong><span>داده‌ها فقط در همین مرورگر · ورود و انتخاب نقش آزمایشی · اطلاعات و رمز واقعی وارد نکنید</span></div>
    <div className="sandbox-controls"><label>سناریوی تست<select aria-label="سناریوی تست" value={mode} disabled={busy||!info} onChange={event=>void changeMode(event.target.value as Mode)}><option value="demo">مدرسهٔ نمونه · ۴۲۰ پرونده</option><option value="empty">نصب خالی · ساخت ادمین اولیه</option></select></label>
    {mode==='demo'&&<><label>نقش نمونه<select aria-label="نقش نمونه برای آزمایش" value={role} disabled={busy||!info} onChange={event=>setRole(event.target.value)}>{Object.entries(roles).map(([id,label])=><option key={id} value={id}>{label}</option>)}</select></label><button className="primary" disabled={busy||!info} onClick={()=>void action(async()=>{await rpc({kind:'role',role});location.hash='home';})}>امتحان این نقش</button></>}
    <button disabled={busy||!info} onClick={()=>setConfirmReset(!confirmReset)}>نمونهٔ تازه</button>{info?.canRestore&&<button disabled={busy} onClick={()=>void action(async()=>setInfo(await rpc<Info>({kind:'restore'})))}>بازگردانی نمونهٔ قبلی</button>}
    {window.self===window.top&&<a className="button-link" href="./display-check.html">بررسی نمایش گوشی و تبلت</a>}
    </div>{confirmReset&&<div className="sandbox-confirm"><p>داده‌های این سناریو به نمونهٔ تازه تغییر می‌کند. نسخهٔ قبلی برای بازگردانی حفظ می‌شود.</p><button className="primary" onClick={()=>void action(async()=>setInfo(await rpc<Info>({kind:'reset'})))}>ساخت نمونهٔ تازه</button><button onClick={()=>setConfirmReset(false)}>انصراف</button></div>}
    {error&&<p className="error-text" role="alert">{error} <button onClick={()=>location.reload()}>بازخوانی محیط تست</button></p>}
  </section>
  {busy?<main className="sandbox-loading" aria-live="polite"><div className="sandbox-spinner"/><h1>مدرسه برای آزمایش آماده می‌شود</h1><p>{progress}</p><small>بار نخست موتور اجرای Python دریافت می‌شود. داده‌ها به Supabase یا سرور دیگری ارسال نمی‌شوند.</small></main>:info?<div className="sandbox-app" key={revision}><App/></div>:null}
  </>;
}
createRoot(document.getElementById('root')!).render(<Sandbox/>);
