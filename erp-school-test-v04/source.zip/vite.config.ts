import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({base:'./',plugins:[react()],server:{allowedHosts:['terminal.local']},build:{outDir:'dist',emptyOutDir:true,target:'es2020'}});
