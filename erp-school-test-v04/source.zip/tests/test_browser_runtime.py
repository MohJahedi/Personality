"""The same assertions run in CPython and the pinned browser WASM runtime."""
from datetime import date
import base64
import json
from pathlib import Path
import sqlite3
import unittest
import browser_bridge as bridge


class BrowserRuntimeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.info = json.loads(bridge.initialize('school-test.example','demo'))
        bridge.select_demo_role('system_admin')

    def api(self, path, payload=None, expected=200):
        result = bridge._dispatch('/api/v1'+path,payload)
        body = json.loads(base64.b64decode(result['body64']))
        self.assertEqual(result['status'],expected,body)
        return body

    def admin(self):
        bridge.select_demo_role('system_admin')

    def test_01_real_database_420_records_and_role_scopes(self):
        self.admin()
        year = next(y['id'] for y in self.api('/years')['academicYears'] if y['status']=='active')
        self.assertEqual(len(self.api('/students?yearId='+year)['students']),420)
        for role, count in [('teacher',30),('parent',2),('student',1)]:
            bridge.select_demo_role(role)
            self.assertEqual(len(self.api('/students?yearId='+year)['students']),count)
            self.api('/users',expected=403)
        self.admin()

    def test_02_preferences_survive_application_recreation(self):
        self.admin()
        payload={'font':'sahel','size':'large','theme':'violet','accent':'#0e7490'}
        self.api('/preferences',payload)
        bridge.initialize('school-test.example','demo')
        self.admin()
        self.assertEqual(self.api('/context')['preferences'],payload)

    def test_03_carry_and_payment_share_original_claim(self):
        self.admin()
        years = self.api('/years')['academicYears']
        source = next(y['id'] for y in years if y['status']=='active')
        target = next(y['id'] for y in years if y['status']=='draft')
        copy = self.api('/years/copy-preview?sourceId='+source+'&targetId='+target)
        self.api('/years/copy', {'sourceId':source,'targetId':target,
            'options':dict(students=True,teachers=True,parents=True,classes=True),
            'version':copy['version'],'eventKey':'browser-test-copy'})
        carry = self.api('/years/carry-preview?sourceId='+source+'&targetId='+target)
        self.api('/years/carry', {'sourceId':source,'targetId':target,
            'studentIds':[],'version':carry['version'],'eventKey':'browser-test-carry'})
        before = self.api('/balances?yearId='+target)['total']
        fiscal = self.api('/years')['fiscalYears'][0]['id']
        payload={'invoiceId':carry['claims'][0]['invoice_id'],'amount':'1000',
            'reference':'آزمون بدون تراکنش بانکی','fiscalYearId':fiscal,
            'postedOn':date.today().isoformat(),'eventKey':'browser-test-receipt'}
        self.api('/finance/receipts',payload)
        self.api('/finance/receipts',payload)
        self.assertEqual(self.api('/balances?yearId='+target)['total'],before-10000)
        self.api('/finance/receipts',{**payload,'amount':'1000000000','eventKey':'too-much'},expected=409)

    def test_04_daily_periods_and_teacher_collision_are_real(self):
        self.admin()
        year = next(y['id'] for y in self.api('/years')['academicYears'] if y['status']=='active')
        catalog = self.api('/academics?yearId='+year)
        periods=catalog['periods']
        self.assertEqual(sum(p['weekday']==0 for p in periods),4)
        self.assertEqual(sum(p['weekday']==1 for p in periods),3)
        first=self.api('/timetable?yearId='+year)['timetable'][0]
        other=next(c for c in catalog['classes'] if c['id']!=first['class_id'])
        self.api('/timetable', {'classId':other['id'],'periodId':first['period_id'],
            'subjectId':first['subject_id'],'teacherId':first['teacher_id']},expected=409)
        self.assertEqual(len(self.api('/timetable?yearId='+year)['timetable']),3)

    def test_05_real_custom_role_user_and_temporary_password(self):
        self.admin()
        role=self.api('/roles',{'name':'نقش مخصوص تست','permissions':['academics.read']})['id']
        user=self.api('/users',{'username':'qa.browser','password':'Temporary-test-1405!',
            'name':'کاربر ساختگی تست','roles':[role],'classIds':[],'studentIds':[]})['id']
        record=next(u for u in self.api('/users')['users'] if u['id']==user)
        self.assertEqual(record['roles'],[role])
        self.api('/auth',{'action':'logout'})
        self.api('/auth',{'action':'login','username':'qa.browser','password':'Temporary-test-1405!'})
        self.assertTrue(self.api('/context')['user']['must_change_password'])
        self.api('/years',expected=403)
        self.api('/password',{'currentPassword':'Temporary-test-1405!','newPassword':'Changed-test-1405!'})
        self.assertFalse(self.api('/context')['user']['must_change_password'])
        self.admin()

    def test_06_empty_install_and_reversible_reset(self):
        bridge.initialize('school-test.example','empty')
        self.assertTrue(self.api('/context')['setupRequired'])
        self.api('/auth',{'action':'setup','username':'own.admin','password':'Local-only-test-1405!', 'name':'ادمین آزمایشی تازه'})
        self.assertEqual(self.api('/context')['user']['roles'],['system_admin'])
        self.api('/auth',{'action':'setup','username':'other.admin','password':'Local-only-test-1405!', 'name':'تکرار نامجاز'},expected=409)
        bridge.reset_sandbox()
        self.assertTrue(self.api('/context')['setupRequired'])
        bridge.reset_sandbox(restore=True)
        self.assertFalse(self.api('/context')['setupRequired'])
        bridge.initialize('school-test.example','demo')
        self.admin()

    def test_07_backup_is_a_valid_database_and_contains_no_raw_password(self):
        self.admin()
        response=bridge._dispatch('/api/backup')
        self.assertEqual(response['status'],200)
        raw=base64.b64decode(response['body64'])
        self.assertTrue(raw.startswith(b'SQLite format 3'))
        self.assertNotIn(bridge.DEMO_PASSWORD.encode(),raw)
        backup=bridge.DATA_ROOT/'browser-test-backup.sqlite3'
        backup.write_bytes(raw)
        with sqlite3.connect(backup) as db:
            self.assertEqual(db.execute('PRAGMA integrity_check').fetchone()[0],'ok')
            self.assertEqual(db.execute('PRAGMA foreign_key_check').fetchall(),[])


if __name__=='__main__':
    unittest.main()
