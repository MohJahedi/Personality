import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
try {
  const {loadPyodide}=await import(process.argv[2]||'pyodide');
  const runtime=await loadPyodide({stdout:text=>console.log(text),stderr:text=>console.error(text)});
  const {pbkdf2_hex}=await import('../public/crypto-runtime.mjs');
  const crypto=await import('node:crypto');
  for(const [password,salt,count] of [['password','salt',1],['رمز آزمایشی','نمک',2],['only-test','abc',600000]]){
    const passwordHex=Buffer.from(password).toString('hex'),saltHex=Buffer.from(salt).toString('hex');
    const expected=crypto.pbkdf2Sync(password,salt,count,32,'sha256').toString('hex');
    if(pbkdf2_hex(passwordHex,saltHex,count,32)!==expected)throw new Error('PBKDF2 compatibility check failed');
  }
  console.log('PBKDF2 SHA-256 compatibility: 3 vectors passed, including 600,000 iterations.');
  runtime.registerJsModule('school_crypto',{pbkdf2_hex});
  runtime.FS.writeFile('/school-backend.zip',await fs.readFile(path.join(root,'public/backend.zip')));
  runtime.FS.writeFile('/test_browser_runtime.py',await fs.readFile(path.join(root,'tests/test_browser_runtime.py')));
  const result=runtime.runPython(`
import zipfile, sys, unittest, json
zipfile.ZipFile('/school-backend.zip').extractall('/school-source')
sys.path.insert(0,'/school-source')
sys.path.insert(0,'/')
import test_browser_runtime
result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(test_browser_runtime))
json.dumps({'successful':result.wasSuccessful(),'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors)})
`);
  console.log('WASM result:',result);
  if(!JSON.parse(result).successful)process.exitCode=1;
}catch(error){console.error(error.name+': '+error.message);process.exitCode=1;}
