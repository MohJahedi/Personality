"""Generate a synthetic seed through the real v0.4 commands; never copy school data."""
from pathlib import Path
import sys
import tempfile
import sqlite3

root=Path(__file__).resolve().parents[1]
source=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(source/'backend'))
sys.path.insert(0,str(root/'runtime'))
import browser_bridge as bridge
bridge.DATA_ROOT=Path(tempfile.mkdtemp(prefix='school-public-synthetic-seed-'))
bridge.META_PATH=bridge.DATA_ROOT/'sandbox.json'
bridge.initialize('school-test.example','demo')
with bridge.application.database.transaction() as db:
    db.execute('DELETE FROM local_sessions')
with bridge.application.database.connection() as original, sqlite3.connect(root/'runtime/demo-seed.sqlite3') as destination:
    original.backup(destination)
    assert destination.execute('SELECT COUNT(*) FROM students').fetchone()[0]==420
    assert destination.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    assert destination.execute('PRAGMA foreign_key_check').fetchall()==[]
print('Created a public synthetic seed: 420 anonymous test records, 6 demo roles, zero live sessions.')
