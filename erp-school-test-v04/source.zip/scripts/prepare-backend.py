"""Package only the real v0.4 backend source and the separate browser bridge."""
from pathlib import Path
import hashlib
import json
import sys
import zipfile

root = Path(__file__).resolve().parents[1]
source = Path(sys.argv[1]).resolve()
files = sorted(p for p in (source/'backend').rglob('*')
               if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc')
manifest = {}
with zipfile.ZipFile(root/'public/backend.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        relative = path.relative_to(source).as_posix()
        raw = path.read_bytes()
        archive.writestr(relative,raw)
        manifest[relative] = hashlib.sha256(raw).hexdigest()
    archive.write(root/'runtime/browser_bridge.py','browser_bridge.py')
    template=root/'runtime/demo-seed.sqlite3'
    if template.exists():
        archive.write(template,'demo-seed.sqlite3')
(root/'public/source-provenance.json').write_text(json.dumps({
    'productVersion':'0.4.0',
    'sourceCommit':'2febba4fcb073be3fcbf416285b644afde3d7635',
    'sourceRepository':'MohJahedi/Personality',
    'runtime':'Pyodide 314.0.7',
    'mode':'browser-local product test; not a hosted database or production auth',
    'backendSha256':manifest,
},ensure_ascii=False,indent=2)+'\n')
print(f'Packaged {len(files)} unchanged backend source files; no runtime data or QA stories.')
