"""Local-only product sandbox. Runs the unchanged v0.4 WSGI application.

No requests reach an application server. Demo-role selection is deliberately
available to anyone controlling this browser and is not authentication security.
"""
import base64
from datetime import date, timedelta
from http.cookies import SimpleCookie
import io
import json
from pathlib import Path
import hashlib
import secrets
import sqlite3
import sys
from urllib.parse import urlsplit

# Pyodide ships SHA-256 but not OpenSSL's synchronous PBKDF2 helper.
# Supply only this missing primitive from the pinned, locally bundled JS library.
if not hasattr(hashlib, 'pbkdf2_hmac'):
    from school_crypto import pbkdf2_hex
    def _browser_pbkdf2(algorithm, password, salt, iterations, dklen=None):
        if algorithm != 'sha256' or not 1 <= iterations <= 2_000_000:
            raise ValueError('Unsupported browser PBKDF2 request')
        return bytes.fromhex(str(pbkdf2_hex(password.hex(), salt.hex(), iterations, dklen or 32)))
    hashlib.pbkdf2_hmac = _browser_pbkdf2

sys.path.insert(0, '/school-source/backend')
from erp_school.bootstrap import create_application

DATA_ROOT = Path('/school-browser-test-v04')
META_PATH = DATA_ROOT / 'sandbox.json'
DEMO_PASSWORD = 'Only-For-Test-1405!'
ROLE_LABELS = {
    'system_admin': 'ادمین سیستم', 'manager': 'مدیر',
    'accountant': 'حسابدار', 'teacher': 'معلم', 'parent': 'ولی',
    'student': 'دانش‌آموز',
}
application = None
cookie_jar = ''
host = ''
mode = 'demo'
metadata = {}


def _save_metadata():
    META_PATH.write_text(json.dumps(metadata), encoding='utf-8')


def _dispatch(path, payload=None):
    global cookie_jar
    url = urlsplit(path)
    body = json.dumps(payload, ensure_ascii=False).encode() if payload is not None else b''
    environ = {
        'REQUEST_METHOD': 'POST' if payload is not None else 'GET',
        'PATH_INFO': url.path, 'QUERY_STRING': url.query,
        'HTTP_HOST': host, 'HTTP_ORIGIN': 'https://' + host,
        'HTTP_X_SCHOOL_ERP': '1', 'HTTP_COOKIE': cookie_jar,
        'CONTENT_TYPE': 'application/json', 'CONTENT_LENGTH': str(len(body)),
        'REMOTE_ADDR': 'browser-sandbox', 'wsgi.input': io.BytesIO(body),
        'wsgi.url_scheme': 'https',
    }
    response = {}
    def start_response(status, headers):
        response['status'] = int(status.split()[0])
        response['headers'] = []
        for key, value in headers:
            if key.lower() == 'set-cookie':
                parsed = SimpleCookie(value)
                if 'school_session' in parsed:
                    nonlocal_cookie = parsed['school_session'].value
                    globals()['cookie_jar'] = 'school_session=' + nonlocal_cookie if nonlocal_cookie else ''
            elif key.lower() not in ('content-length',):
                response['headers'].append([key, value])
    raw = b''.join(application(environ, start_response))
    response['body64'] = base64.b64encode(raw).decode('ascii')
    return response


def _api(path, payload=None):
    response = _dispatch('/api/v1' + path, payload)
    result = json.loads(base64.b64decode(response['body64']))
    if response['status'] >= 400:
        raise RuntimeError(f"Sandbox seed {path}: {result.get('error')}")
    return result


def _seed():
    """Synthetic records go through the real application commands, not UI mocks."""
    global cookie_jar
    _api('/auth', {'action': 'setup', 'username': 'admin.test',
                  'password': DEMO_PASSWORD, 'name': 'ادمین مدرسهٔ آزمایشی'})
    today = date.today()
    start_year = today.year if today >= date(today.year, 9, 23) else today.year - 1
    academic_start = date(start_year, 9, 23)
    academic_end = date(start_year + 1, 9, 23) - timedelta(days=1)
    year_id = _api('/years', {'title': f'{start_year-621}–{start_year-620}',
        'starts_on': academic_start.isoformat(), 'ends_on': academic_end.isoformat(), 'status': 'active'})['id']
    _api('/years', {'title': f'{start_year-620}–{start_year-619}',
        'starts_on': date(start_year+1,9,23).isoformat(),
        'ends_on': (date(start_year+2,9,23)-timedelta(days=1)).isoformat(), 'status': 'draft'})
    fiscal_start_year = today.year if today >= date(today.year,3,21) else today.year - 1
    fiscal_id = _api('/fiscal-years', {'title': f'مالی {fiscal_start_year-621}',
        'starts_on': date(fiscal_start_year,3,21).isoformat(),
        'ends_on': (date(fiscal_start_year+1,3,21)-timedelta(days=1)).isoformat(), 'status': 'active'})['id']
    grade = _api('/academics', {'kind':'grade','name':'پنجم','position':5})['id']
    subjects = [_api('/academics', {'kind':'subject','gradeId':grade,'name':name})['id']
                for name in ('ریاضی','علوم','فارسی')]
    teachers = [_api('/academics', {'kind':'teacher','yearId':year_id,'name':f'آموزگار آزمایشی {i}'})['id']
                for i in range(1,4)]
    classes = [_api('/academics', {'kind':'class','yearId':year_id,'gradeId':grade,
                'name':f'پنجم · کلاس آزمایشی {i:02}','capacity':30})['id'] for i in range(1,15)]
    students = []
    for i in range(420):
        students.append(_api('/students', {'yearId':year_id,'classId':classes[i//30],
            'name':f'دانش‌آموز آزمایشی {i+1:03}', 'code':f'TEST-{i+1:03}',
            'guardianName':f'ولی آزمایشی {i+1:03}','guardianPhone':''})['id'])
    for weekday, count in ((0,4),(1,3),(2,4),(3,2),(4,4)):
        _api('/periods', {'yearId':year_id,'gradeId':grade,'weekday':weekday,
            'periods':[{'starts_at':f'{8+i:02}:00','ends_at':f'{8+i:02}:45'} for i in range(count)]})
    catalog = _api('/academics?yearId='+year_id)
    saturday = [p for p in catalog['periods'] if p['weekday']==0]
    for i in range(3):
        _api('/timetable', {'classId':classes[0],'periodId':saturday[i]['id'],
            'subjectId':subjects[i],'teacherId':teachers[i]})
    for i in range(6):
        invoice = _api('/finance/invoices', {'yearId':year_id,'fiscalYearId':fiscal_id,
            'postedOn':today.isoformat(),'studentId':students[i], 'title':'شهریهٔ آزمایشی',
            'amount':40000000,'dueDate':(today+timedelta(days=30)).isoformat(),
            'eventKey':'sandbox-invoice-'+str(i)})['id']
        if i < 2:
            _api('/finance/receipts', {'invoiceId':invoice,'amount':12000000,
                'reference':'رسید ساختگی','fiscalYearId':fiscal_id,'postedOn':today.isoformat(),
                'eventKey':'sandbox-receipt-'+str(i)})
    demo_ids = {'system_admin': _api('/context')['user']['id']}
    for role in ROLE_LABELS:
        if role == 'system_admin':
            continue
        ident = _api('/users', {'username':role+'.test','password':DEMO_PASSWORD,
            'name':ROLE_LABELS[role]+' آزمایشی','roles':[role],
            'classIds':[classes[0]] if role=='teacher' else [],
            'studentIds':students[:2] if role=='parent' else students[:1] if role=='student' else []})['id']
        demo_ids[role] = ident
    # Demo accounts are intentionally ready to explore. Newly created user
    # accounts still use the real mandatory-password-change workflow.
    with application.database.transaction() as db:
        for ident in demo_ids.values():
            db.execute('UPDATE user_security SET must_change_password=0 WHERE user_id=?', (ident,))
    item = metadata['slots'][mode]
    item['demo_ids'] = demo_ids
    _save_metadata()
    _api('/auth', {'action':'logout'})
    cookie_jar = ''


def initialize(hostname, selected_mode='demo'):
    global application, cookie_jar, host, mode, metadata
    if selected_mode not in ('demo','empty'):
        raise ValueError('Unknown sandbox mode')
    DATA_ROOT.mkdir(exist_ok=True)
    host, mode, cookie_jar = hostname, selected_mode, ''
    metadata = json.loads(META_PATH.read_text()) if META_PATH.exists() else {'slots':{},'previous':{}}
    if mode not in metadata['slots']:
        metadata['slots'][mode] = {'directory': mode+'-'+secrets.token_hex(8)}
        _save_metadata()
    item = metadata['slots'][mode]
    directory = DATA_ROOT/item['directory']
    template = Path(__file__).with_name('demo-seed.sqlite3')
    if mode == 'demo' and not (directory/'school.sqlite3').exists() and template.exists():
        directory.mkdir(mode=0o700,parents=True,exist_ok=True)
        with sqlite3.connect(template) as original, sqlite3.connect(directory/'school.sqlite3') as destination:
            original.backup(destination)
    application = create_application(directory, [host], secure_cookie=True)
    with application.database.connection() as db:
        empty = not db.execute('SELECT 1 FROM local_users LIMIT 1').fetchone()
    if mode == 'demo' and empty:
        _seed()
    elif mode == 'demo' and not item.get('demo_ids'):
        with application.database.connection() as db:
            item['demo_ids'] = {role:db.execute('SELECT id FROM local_users WHERE username=?',
                ('admin.test' if role=='system_admin' else role+'.test',)).fetchone()[0] for role in ROLE_LABELS}
        _save_metadata()
    return json.dumps({'mode':mode,'demoRoles':list(metadata['slots'][mode].get('demo_ids',{})),
                       'canRestore':mode in metadata['previous']})


def select_demo_role(role):
    """Explicit local demo control; never exists in the hosted production API."""
    global cookie_jar
    ident = metadata['slots'][mode].get('demo_ids',{}).get(role)
    if not ident:
        raise ValueError('This mode has no matching demo account')
    with application.database.transaction() as db:
        member = db.execute('SELECT status FROM memberships WHERE user_id=?',(ident,)).fetchone()
        if not member or member[0] != 'active':
            raise ValueError('حساب نمونه غیرفعال است؛ با ادمین اصلاح کنید یا دادهٔ نمونه را بازنشانی کنید.')
        cookie_jar = 'school_session='+application.identity.new_session(db,ident)
    return json.dumps({'ok':True})


def reset_sandbox(restore=False):
    global metadata
    if restore:
        if mode not in metadata['previous']:
            raise ValueError('No previous sandbox')
        metadata['slots'][mode], metadata['previous'][mode] = metadata['previous'][mode], metadata['slots'][mode]
    else:
        metadata['previous'][mode] = metadata['slots'][mode]
        metadata['slots'][mode] = {'directory':mode+'-'+secrets.token_hex(8)}
    _save_metadata()
    return initialize(host, mode)


def handle_request(request_json):
    request = json.loads(request_json)
    path, method = request['path'], request.get('method','GET')
    if method not in ('GET','POST') or not (path.startswith('/api/v1/') or path=='/api/backup'):
        raise ValueError('Sandbox accepts only the school API')
    return json.dumps(_dispatch(path, request.get('body') if method=='POST' else None))
