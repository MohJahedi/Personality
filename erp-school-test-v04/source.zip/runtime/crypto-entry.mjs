// MPL/Python runtime lacks this OpenSSL helper. Match CPython PBKDF2-SHA256.
import {pbkdf2} from '@noble/hashes/pbkdf2.js';
import {sha256} from '@noble/hashes/sha2.js';
import {hexToBytes,bytesToHex} from '@noble/hashes/utils.js';
export function pbkdf2_hex(passwordHex,saltHex,iterations,length){
  if(!Number.isInteger(iterations)||iterations<1||iterations>2_000_000||!Number.isInteger(length)||length<1||length>64)throw new Error('Unsupported PBKDF2 parameters');
  return bytesToHex(pbkdf2(sha256,hexToBytes(passwordHex),hexToBytes(saltHex),{c:iterations,dkLen:length}));
}
