import {defineConfig} from 'vite';
export default defineConfig({publicDir:false,build:{outDir:'public',emptyOutDir:false,target:'es2020',
  lib:{entry:'runtime/crypto-entry.mjs',formats:['es'],fileName:()=>'crypto-runtime.mjs'}}});
